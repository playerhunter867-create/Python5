# PyFlow — Python on Android

PyFlow is an Android Python coding workspace with a mobile-first UI and an embedded CPython 3.11 runtime powered by Chaquopy.

## Features
- Runs real Python code locally inside the Android app.
- Python standard library available through the embedded runtime.
- Persistent Python namespace between runs (variables remain available).
- Console output and tracebacks.
- Mobile-first editor, autosave, Tab indentation and automatic indentation after `:`.
- Six quick-start examples.
- GitHub Actions workflow to build a debug APK.

## Build on GitHub from your phone
1. Create a repository on GitHub.
2. Upload the contents of this ZIP to the repository root (make sure `.github/workflows/android.yml` is included).
3. Open **Actions** and run **Build PyFlow APK**.
4. Download the `PyFlow-debug-apk` artifact from the successful workflow run.

## Build locally
Use Android Studio with JDK 17 and Android SDK Platform 35. Open this folder as a Gradle project and build `:app:assembleDebug`.

## Python support
This embeds CPython 3.11, not a fake command simulator. The Python language and standard library are available subject to Android/Chaquopy platform limits. The project includes `requests`; packages with native extensions may require Chaquopy-compatible wheels. It is not a full desktop Linux environment and does not include every package from PyPI.

## Project structure
- `app/src/main/java/com/pyflow/app/MainActivity.kt` — Android shell and Python bridge
- `app/src/main/python/runner.py` — Python execution engine
- `app/src/main/assets/index.html` — mobile IDE interface
- `.github/workflows/android.yml` — APK build automation

## License
MIT — see `LICENSE`.
