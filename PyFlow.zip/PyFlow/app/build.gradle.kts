plugins {
    id("com.android.application")
    id("com.chaquo.python")
}

android {
    namespace = "com.pyflow.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pyflow.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        python {
            version = "3.11"
            pip {
                install("requests")
            }
        }
    }
}
