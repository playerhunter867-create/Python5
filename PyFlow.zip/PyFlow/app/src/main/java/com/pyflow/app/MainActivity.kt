package com.pyflow.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val executor = Executors.newSingleThreadExecutor()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(10, 14, 24))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "PyFlow")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun runPython(code: String) {
            executor.execute {
                val result = try {
                    Python.getInstance().getModule("runner").callAttr("run_code", code).toString()
                } catch (e: Exception) {
                    "Runtime error: ${e.message ?: e.javaClass.simpleName}"
                }
                val escaped = org.json.JSONObject.quote(result)
                runOnUiThread { web.evaluateJavascript("window.onPythonResult($escaped)", null) }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        web.destroy()
        super.onDestroy()
    }
}
