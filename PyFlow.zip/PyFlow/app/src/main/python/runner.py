import contextlib
import io
import traceback

# A persistent namespace keeps variables available between runs.
_namespace = {"__name__": "__main__"}

def run_code(code):
    output = io.StringIO()
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            exec(compile(code, "<PyFlow>", "exec"), _namespace, _namespace)
    except BaseException:
        traceback.print_exc(file=output)
    return output.getvalue() or "✓ Finished with no output."
